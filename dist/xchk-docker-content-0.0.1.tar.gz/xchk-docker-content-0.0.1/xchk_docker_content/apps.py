from django.apps import AppConfig


class DockercontentConfig(AppConfig):
    name = 'xchk_docker_content'
